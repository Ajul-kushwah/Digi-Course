# List_Country_State

Create Country state dropdown by using a JavaScript file.


Advantages:

	No need to create tables in database.

	No jQuery used (only JavaScript).

	You can manually add/delete/update Countries and States.


